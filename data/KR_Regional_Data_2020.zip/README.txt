# South Korea Province-Level Dataset for Environmental and Socioeconomic Regression Studies (2020)

This folder contains datasets compiled for regression analysis of environmental and socioeconomic variables at the province level for South Korea (2020). 
All files are described individually below.

Filename				Description						Source				Temporal resolution
AvgTemp_KR_2020.xlsx		Province-level daily mean temperature (°C)			Korea Meteorological Administration	Daily
AvgWindSpeed_KR_2020.xlsx		Province-level daily mean wind speed (m/s)			Korea Meteorological Administration	Daily
Education_KR_2020.xlsx		Province-level shares of high school and college graduates	KESS				Annual
Income_KR_2020.xlsx		Province-level median annual houshold income (KRW)		KOSIS				Annual
MaxInstWindSpeed_KR_2020.xlsx	Province-level daily maximum instantaneous wind speed (m/s)	Korea Meteorological Administration	Daily
MaxTemp_KR_2020.xlsx		Province-level daily maximum temperature (°C)			Korea Meteorological Administration	Daily
MaxWindSpeed_KR_2020.xlsx		Province-level daily maximum wind speed (m/s)			Korea Meteorological Administration	Daily
MinTemp_KR_2020.xlsx		Province-level daily minimum temperature (°C)			Korea Meteorological Administration	Daily
PM25_KR_2020.xlsx			Province-level daily mean concentration of PM2.5 (µg/m³)	AirKorea				Daily
Population_KR_2020.xlsx		Province-level population					KOSIS				Annual
Precipitation_KR_2020.xlsx		Province-level daily total precipitation (mm)			Korea Meteorological Administration	Daily

## Key Variables and Format
- All files include a header row describing variables.
- Data are provided at the Korean province level unless otherwise noted.
- Units: currency in KRW, PM2.5 in µg/m³, wind speed in m/s, precipitation in mm, temperature in °C.
- Annual datasets aggregate province-level data over the year 2020. Daily datasets are event-based or daily totals per province.

## Data Provenance and Processing Notice
- All datasets listed here were originally downloaded from the respective governmental or public agencies as cited. 
- The data have been organized, harmonized, and preprocessed by the authors for use in this research. 
- Any formatting, aggregation, or data cleaning performed is described in the corresponding methods section of the manuscript or within this README.

## Limitations and Exclusions
- No personally identifiable or sensitive information is included.
- Daily data are aggregated at province level for 2020 resolution may be limited by original data provider.
- Raw Twitter data and tweet texts are not shared due to privacy and Twitter policy restrictions. 
- Summary results are available upon reasonable request and in accordance with Twitter terms of service.

## Citation and License
- If you use these data, please cite:  
  Woo et al., "Spatiotemporal Climate Sentiment Drives Support for Climate Policy across the United States and South Korea," dataset, 2025.  

## Contact
- For questions or requests regarding the dataset, contact the corresponding author in the manuscript.