# U.S. State-Level Dataset for Environmental and Socioeconomic Regression Studies (2019)

This folder contains datasets compiled for regression analysis of environmental and socioeconomic variables at the state level for the United States (2019). 
All files are described individually below.

Filename				Description						Source			Temporal resolution
Education_US_2019.xlsx		State-level shares of high schoool and college graduates 	US Census Bureau		Annual
Flood_Damage_US_2019.xlsx		State-level flood damage records (USD)			NOAA			Daily
Flood_US_2019.xlsx			State-level flood event occurrence				NOAA			Daily
Heat_Deaths_US_2019.xlsx		State-level heat-related mortality				NOAA			Daily
Income_US_2019.xlsx		State-level per capita income				NCES			Annual
PM25_US_2019.csv			State-level annual mean PM2.5 (ug/m3)			US EPA AirData		Daily
Population_US_2019.xlsx		Population by state					US Census Bureau		Annual
Strom_Damage_US_2019.xlsx		State-level strom damage loss records (USD)			NOAA			Daily
Strom_US_2019.xlsx		State-level storm event occurrence				NOAA			Daily
StrongWind_Damage_US_2019.xlsx	State-level windstorm damage records (USD)			NOAA			Daily
StrongWind_US_2019.xlsx		State-level maximum reported wind speed (MPH)		NOAA			Daily

## Key Variables and Format
- All files include a header row describing variables.
- Data are provided at the U.S. state level unless otherwise noted.
- Units: currency in USD, PM2.5 in µg/m³, wind speed in MPH.
- Annual datasets aggregate state-level data over the year 2019. Daily datasets are event-based or daily totals per state.

## Data Provenance and Processing Notice
- All datasets listed here were originally downloaded from the respective governmental or public agencies as cited. 
- The data have been organized, harmonized, and preprocessed by the authors for use in this research. 
- Any formatting, aggregation, or data cleaning performed is described in the corresponding methods section of the manuscript or within this README.

## Limitations and Exclusions
- No personally identifiable or sensitive information is included.
- Daily data are aggregated at state level for 2019; resolution may be limited by original data provider.
- Raw Twitter data and tweet texts are not shared due to privacy and Twitter policy restrictions. 
- Summary results are available upon reasonable request and in accordance with Twitter terms of service.

## Citation and License
- If you use these data, please cite:  
  Woo et al., "Spatiotemporal Climate Sentiment Drives Support for Climate Policy across the United States and South Korea," dataset, 2025.  

## Contact
- For questions or requests regarding the dataset, contact the corresponding author in the manuscript.